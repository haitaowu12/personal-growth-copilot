Open requirements-writing.html in a modern browser. No server or account is needed.
Progress starts in the tab only. Enable device saving or export before closing.
Source links open only when selected. Written exercises are not automatically graded.

The personal-growth-copilot folder is a complete explicit-invocation Agent Skill.
Import it with your compatible host's skill installation workflow. The HTML player
works independently of the skill and needs no Python or Node.js installation.

This is a research candidate, not a production-qualified coaching product or an
independent assessment. Read the included acceptance and pilot documents.
Browser storage on file URLs varies; JSON export/import is the portable resume path.
